class AppConstants {
  AppConstants._internal();
  static const MESSAGE_CHANNEL = 'flutter_branch_sdk/message';
  static const EVENT_CHANNEL = 'flutter_branch_sdk/event';
}
