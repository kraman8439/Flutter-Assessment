# flutter_branch_sdk_example

Demonstrates how to use the flutter_branch_sdk plugin.

## Getting Started

See the `example` directory for a complete sample app using Branch SDK.

![Example app](https://user-images.githubusercontent.com/17687286/70445281-0b87c180-1a7a-11ea-8611-7217d46c75a7.png)