package br.com.rsmarques.flutter_branch_sdk_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
